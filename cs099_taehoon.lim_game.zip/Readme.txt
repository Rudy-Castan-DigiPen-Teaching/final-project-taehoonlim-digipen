//taehoon lim
//cs099
//spring2020
//final project
✔ Tick Sound by DeepFrozenApps
✔ From
http://soundbible.com/2044-Tick.html
✔ Distributor 
‘대한민국 대표 BGM 셀바이뮤직’ https://www.sellbuymusic.com




✔ swords collide sound by Sound Explorer
✔ From
http://soundbible.com/1980-Swords-Collide.html
✔ Distributor 
‘대한민국 대표 BGM 셀바이뮤직’ https://www.sellbuymusic.com



✔ Shooting Star Sound by Mike Koenig
✔ From
http://soundbible.com/1744-Shooting-Star.html
✔ Distributor 
‘대한민국 대표 BGM 셀바이뮤직’ https://www.sellbuymusic.com


✔ Thunder Sound FX Sound by Grant Evans
✔ From
http://soundbible.com/2053-Thunder-Sound-FX.html
✔ Distributor 
‘대한민국 대표 BGM 셀바이뮤직’ https://www.sellbuymusic.com

mainmeny.jpg  I drew it on real canvas


defenseS=✔ Playing Pool Sound by Pool Shot
✔ From
http://soundbible.com/2035-Playing-Pool.html
✔ Distributor 
‘대한민국 대표 BGM 셀바이뮤직’ https://www.sellbuymusic.com
